package com.mseei.hexiwear_read_app;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;

public class Conexion extends AppCompatActivity {
    private static final String MOVEMENT_SERVICE_UUID = "00002000-0000-1000-8000-00805f9b34fb";
    private static final String WEATHER_SERVICE_UUID = "00002010-0000-1000-8000-00805f9b34fb";
    private static final String ACCELEROMETER_UUID = "00002001-0000-1000-8000-00805f9b34fb";
    private static final String PRESSURE_UUID = "00002014-0000-1000-8000-00805f9b34fb";
    private static final String GYROSCOPE_UUID = "00002002-0000-1000-8000-00805f9b34fb";
   // private static final String MAGNETOMETER_UUID = "00002003-0000-1000-8000-00805f9b34fb";

    private ArrayList<byte []> accel_data= new ArrayList<byte[]>();
    private ArrayList<byte []> gyros_data= new ArrayList<byte[]>();
    private ArrayList<String> accelr_data_time= new ArrayList<String>();
    private ArrayList<String> gyros_data_time= new ArrayList<String>();

    private BluetoothDevice bluetoothDevice;
    private BluetoothGatt bluetoothGatt;
    private Button btRecord, btStop, btDisconnect, btTag;
    private EditText etMovementTag;
    private Handler handler = new Handler(Looper.myLooper());
    volatile Boolean  isReading=false;
    private String sBTAddr,movementTag;
    FileOutputStream fOutDataLog;
    SimpleDateFormat dateAndTimeFormat = new SimpleDateFormat("yyyyMMdd_HH:mm:ss:SSS", Locale.UK);

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_conexion);

        btRecord = findViewById(R.id.btRecord);
        btStop = findViewById(R.id.btStop);
        btDisconnect = findViewById(R.id.btRegresar);
        btTag = findViewById(R.id.btSendTag);
        etMovementTag = findViewById(R.id.etTag);

        Bundle extras = getIntent().getExtras();
        sBTAddr = extras.getString("BTAddr");
        BluetoothAdapter bluetoothAdapter = BluetoothAdapter.getDefaultAdapter();
        if (bluetoothAdapter != null) {
            bluetoothDevice = bluetoothAdapter.getRemoteDevice(sBTAddr);
        }
        connectToDevice();
    }

    @SuppressLint("MissingPermission")
    private void connectToDevice() {
        bluetoothGatt = bluetoothDevice.connectGatt(this, true, new BluetoothGattCallback() {
            @Override
            public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    showToast(getString(R.string.DeviceConnected));
                    gatt.discoverServices();
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    showToast(getString(R.string.DeviceDisconnect));
                }
            }
            @Override
            public void onCharacteristicRead(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status) {
                if (status == BluetoothGatt.GATT_SUCCESS) {
                    try {
                        displayData(characteristic);
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    showToast(getString(R.string.FailRead));
                }
            }
        });
    }

    public void onClickRead(View v){
        startSensorReading();
    }

    private void showToast(final String message) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
            }
        });
    }
    private void startSensorReading() {
        isReading = true;
        btTag.setEnabled(false);
        btDisconnect.setEnabled(false);
        handler.postDelayed(sensorReadingRunnable, 0); //Start read
    }

    private final Runnable sensorReadingRunnable = new Runnable() {
        @Override
        public void run() {
            if(isReading) {
                //Read each characteristic separate
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        readCharacteristic(UUID.fromString(MOVEMENT_SERVICE_UUID), UUID.fromString(ACCELEROMETER_UUID));
                    }
                }).start();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        readCharacteristic(UUID.fromString(MOVEMENT_SERVICE_UUID), UUID.fromString(GYROSCOPE_UUID));
                    }
                }).start();
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        readCharacteristic(UUID.fromString(WEATHER_SERVICE_UUID), UUID.fromString(PRESSURE_UUID));
                    }
                }).start();
                handler.postDelayed(this, 50); //One read each 50 ms
            }
            else{
                handler.removeCallbacks(sensorReadingRunnable);
            }
        }
    };

    @SuppressLint("MissingPermission")
    private void readCharacteristic(UUID serviceUUID, UUID charUUID) {
        BluetoothGattService service = bluetoothGatt.getService(serviceUUID);
        if (service != null) {
            BluetoothGattCharacteristic characteristic = service.getCharacteristic(charUUID);
            if (characteristic != null) {
                // async read
                bluetoothGatt.readCharacteristic(characteristic);
            }
            else{
                showToast(getString(R.string.NotFound));
            }
        } else {
            showToast(getString(R.string.ServiceNF));
        }
    }


    private void displayData(BluetoothGattCharacteristic characteristic) throws IOException {
        UUID charUUID = characteristic.getUuid();
        String currentTime = dateAndTimeFormat.format(new Date(System.currentTimeMillis()));
        byte[] data = characteristic.getValue();
        switch (charUUID.toString()) {
            case ACCELEROMETER_UUID:
                accel_data.add(data);
                accelr_data_time.add(currentTime);
                break;
            case GYROSCOPE_UUID:
                gyros_data.add(data);
                gyros_data_time.add(currentTime);
                break;
            default:
                showToast(getString(R.string.UnknowFormart));
                break;
        }

    }
    public void createLogFile() {
        String sDateAndTime = dateAndTimeFormat.format(new Date());
        File filePath, fileDataLog;
        String sFileName = "/" + sDateAndTime +"_"+movementTag+ "_DataLog.txt";

        filePath = getFilesDir();
        try {
            fileDataLog = new File(filePath, sFileName);
            fOutDataLog = new FileOutputStream(fileDataLog, true);
        } catch (IOException e) {
            showToast(getString(R.string.ErrorFile));
            isReading=false;
            btTag.setEnabled(true);
            btDisconnect.setEnabled(true);
        }
    }
    public String formatAdapt(byte[] data, String type){
        float xfloatVal,yfloatVal,zfloatVal;
        switch(type){
            case "AC":
                if (data.length == 6) { // Assuming 3 int16 values
                    final int xintVal = ((int) data[1] << 8) | (data[0] & 0xff);
                    xfloatVal = (float) xintVal / 100;

                    final int yintVal = ((int) data[3] << 8) | (data[2] & 0xff);
                    yfloatVal = (float) yintVal / 100;

                    final int zintVal = ((int) data[5] << 8) | (data[4] & 0xff);
                    zfloatVal = (float) zintVal / 100;

                    return(" 1: " + xfloatVal + "," + yfloatVal + "," + zfloatVal +"\n");
                } else {
                    showToast(getString(R.string.InvalidAcData));
                }
                break;
            case "PR":
                if (data.length == 2) { // Assuming 3 int16 values
                    final int xintVal = ((int) data[1] << 8) | (data[0] & 0xff);
                    xfloatVal = (float) xintVal / 100;
                    yfloatVal = 0;
                    zfloatVal = 0;

                    return(" 2: " + xfloatVal + "," + yfloatVal + "," + zfloatVal +"\n");
                } else {
                    showToast(getString(R.string.InvalidPressData));
                }
                break;
            case "GR":
                if (data.length == 6) { // Assuming 3 int16 values
                    final int gyroXintVal = ((int) data[1] << 8) | (data[0] & 0xff);
                    xfloatVal = (float) gyroXintVal;

                    final int gyroYintVal = ((int) data[3] << 8) | (data[2] & 0xff);
                    yfloatVal = (float) gyroYintVal;

                    final int gyroZintVal = ((int) data[5] << 8) | (data[4] & 0xff);
                    zfloatVal = (float) gyroZintVal;

                    return (" 3: " + xfloatVal + "," + yfloatVal + "," + zfloatVal +"\n");
                } else {
                    showToast(getString(R.string.InvalidGyrData));
                }
                break;
        }
        return "";
    }
    @SuppressLint("MissingPermission")
    public void onClickStop(View v) throws IOException {
        if(isReading){
            isReading = false;
            btTag.setEnabled(true);
            createLogFile();
            for (int i=0; i<accel_data.size();i++){
                fOutDataLog.write((accelr_data_time.get(i)+formatAdapt(accel_data.get(i),"AC")).getBytes());
            }
            for (int i=0; i<gyros_data.size();i++){
                fOutDataLog.write((gyros_data_time.get(i)+formatAdapt(gyros_data.get(i),"GR")).getBytes());
            }
            handler.removeCallbacks(sensorReadingRunnable);
            fOutDataLog.close();
            btDisconnect.setEnabled(true);
        }
    }

    @SuppressLint("MissingPermission")
    public void onClickReturn (View v) throws IOException {
        if(isReading){
            isReading = false;
            btTag.setEnabled(true);
            handler.removeCallbacks(sensorReadingRunnable);
            fOutDataLog.close();
        }
        Intent intent = new Intent (this, Opciones.class);
        intent.putExtra("BTAddr",sBTAddr);
        startActivity(intent);
        finish();
    }

    public void onClickSendTag (View v) throws IOException {
        if(!isReading){
            movementTag=String.valueOf(etMovementTag.getText());
            btTag.setEnabled(false);
        }
    }
}
